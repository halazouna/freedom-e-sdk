""" For issue #25 """
class Base(object):
    pass