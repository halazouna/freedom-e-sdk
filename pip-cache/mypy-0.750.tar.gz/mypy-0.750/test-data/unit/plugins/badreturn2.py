class MyPlugin:
    pass

def plugin(version):
    return MyPlugin
