import typing
print('Hello, world')
